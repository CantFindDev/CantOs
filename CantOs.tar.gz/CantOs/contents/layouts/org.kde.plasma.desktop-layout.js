/******* Top Panel*********/
TopPanel = new Panel
TopPanel.hiding = "none"
TopPanel.location = "top"
TopPanel.floating = 0
TopPanel.height = 28
TopPanel.lengthMode = "fill"
const width = screenGeometry(TopPanel.screen).width
/**/

function separators(a){
    if (width <= 1280){
        c = 1
    } else { if (width <= 1440){
        c = 2
    } else
    {
        c = 3
    }
    }
    for (b = 0; b < c; b++)
        a.addWidget("org.kde.plasma.marginsseparator")
}
function separatorsTray(){
    if (width <= 1280){
        c = 2
    } else { if (width <= 1440){
        c = 4
    } else
    {
        c = 6
    }
    }
    return c
}

let localerc;
try {
    localerc = ConfigFile('plasma-localerc');
    localerc.group = "Formats";
} catch (e) {
    localerc = null;
}

let leng = "en";
if (localerc) {
    let langEntry = localerc.readEntry("LANG");
    if (langEntry !== "") {
        leng = langEntry;
    }
}

let textlengu = leng.substring(0, 2);

function desktoptext(languageCode) {
    const translations = {
        "es": "Escritorio",         // Spanish
        "en": "Desktop",            // English
        "hi": "डेस्कटॉप",           // Hindi
        "fr": "Bureau",             // French
        "de": "Desktop",            // German
        "it": "Desktop",            // Italian
        "tr":"Masaüstü",       //Turkish
        "pt": "Área de trabalho",   // Portuguese
        "ru": "Рабочий стол",       // Russian
        "zh": "桌面",               // Chinese (Mandarin)
        "ja": "デスクトップ",        // Japanese
        "ko": "데스크톱",            // Korean
        "nl": "Bureaublad",         // Dutch
        "ny": "Detskyopi",          // Chichewa
        "mk": "Десктоп"             // Macedonian
    };

    // Return the translation for the language code or default to English if not found
    return translations[languageCode] || translations["en"];
}
separators(TopPanel)

AppleMenu = TopPanel.addWidget("org.latgardi.darwinmenu")
AppleMenu.currentConfigGroup = ["Configuration"]
AppleMenu.writeConfig("popupWidth", "400")

TopPanel.addWidget("org.kde.plasma.marginsseparator")

AppTitle = TopPanel.addWidget("org.kde.windowtitle.Fork")
AppTitle.currentConfigGroup = ["General"]
AppTitle.writeConfig("customText", "true")
AppTitle.writeConfig("showIcon", "false")
AppTitle.writeConfig("textDefault", desktoptext(textlengu))

TopPanel.addWidget("org.kde.plasma.appmenu")

TopPanel.addWidget("org.kde.plasma.panelspacer")
systraprev = TopPanel.addWidget("org.kde.plasma.systemtray")
TopPanel.addWidget("org.kde.plasma.marginsseparator")
TopPanel.addWidget("Plasma.Control.Hub")
SystrayContainmentId = systraprev.readConfig("SystrayContainmentId")
const systray = desktopById(SystrayContainmentId)
systray.currentConfigGroup = ["General"]
systray.writeConfig("iconSpacing", "1")
systray.writeConfig("scaleIconsToFit", "true")

TopPanel.addWidget("org.kde.plasma.marginsseparator")

Clock = TopPanel.addWidget("org.kde.plasma.digitalclock")
Clock.currentConfigGroup = ["Appearance"]
Clock.writeConfig("customDateFormat", "ddd d MMM")
Clock.writeConfig("dateFormat", "custom")
Clock.writeConfig("showDate", "false")
Clock.writeConfig("dateDisplayFormat", "BesideTime")
Clock.writeConfig("fontStyleName", "bold")
Clock.writeConfig("autoFontAndSize", "false")
Clock.writeConfig("boldText", "true")
Clock.writeConfig("fontWeight", 700)
Clock.writeConfig("use24hFormat", "0")
Clock.writeConfig("fontSize",7)

separators(TopPanel)

PeekDesktop = TopPanel.addWidget("org.kde.plasma.win7showdesktop")
PeekDesktop.currentConfigGroup = ["General"]
PeekDesktop.writeConfig("size","10")
PeekDesktop.writeConfig("edgeColor","#00000000")
PeekDesktop.writeConfig("hoveredColor","#26010101")
PeekDesktop.writeConfig("pressedColor","#af000000")
PeekDesktop.writeConfig("peekingEnabled","true")
PeekDesktop.writeConfig("peekingThreshold","1000")

/****************************/
BottomPanel = new Panel
BottomPanel.location = "bottom"
BottomPanel.height = 65
BottomPanel.offset = 0
BottomPanel.floating = 1
BottomPanel.alignment = "center"
BottomPanel.hiding = "dodgewindows"
BottomPanel.lengthMode = "fit"
BottomPanel.addWidget("org.kde.plasma.marginsseparator")

/*Launchpad*/
LaunchPad = BottomPanel.addWidget("org.kde.plasma.kickerdash")
LaunchPad.currentConfigGroup = ["General"]
LaunchPad.writeConfig("icon", "app-launcher")
/**/

BottomPanel.addWidget("org.kde.plasma.icontasks")
BottomPanel.addWidget("zayron.simple.separator")
BottomPanel.addWidget("org.kde.plasma.marginsseparator")
BottomPanel.addWidget("org.kde.plasma.calculator")
/*Trash*/
BottomPanel.addWidget("org.kde.plasma.trash")
/*separator*/
BottomPanel.addWidget("org.kde.plasma.marginsseparator")
/*separator /*/
/******************************/
/*Dolphin Config*/
const IconsStatic_dolphin = ConfigFile('dolphinrc')
IconsStatic_dolphin.group = 'KFileDialog Settings'
IconsStatic_dolphin.writeEntry('Places Icons Static Size', 16)
const PlacesPanel = ConfigFile('dolphinrc')
PlacesPanel.group = 'PlacesPanel'
PlacesPanel.writeEntry('IconSize', 16)
/*Buttons of aurorae*/
Buttons = ConfigFile("kwinrc")
Buttons.group = "org.kde.kdecoration2"
Buttons.writeEntry("ButtonsOnRight", "")
Buttons.writeEntry("ButtonsOnLeft", "XIA")
/******************************/
/* accent color config*/
ColorAccetFile = ConfigFile("kdeglobals")
ColorAccetFile.group = "General"
ColorAccetFile.writeEntry("accentColorFromWallpaper", "false")
ColorAccetFile.deleteEntry("AccentColor")
ColorAccetFile.deleteEntry("LastUsedCustomAccentColor")
